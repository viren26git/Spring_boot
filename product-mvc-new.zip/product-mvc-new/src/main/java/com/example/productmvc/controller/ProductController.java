package com.example.productmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.productmvc.model.Product;
import com.example.productmvc.service.ProductService;

@Controller
public class ProductController {
	
	private ProductService productService;
	
	public ProductController(ProductService productService)
	{
		this.productService = productService;
	}
	
	@GetMapping("/")
	public String home() {
		return "home";
	}
	
	@GetMapping("/products")
	public String products(Model model) {
		
		model.addAttribute("products", productService.getAllProducts());    // object to be returned 
		return "products";  // name of the html page to be called
	}
	
	@GetMapping("/products/add")
	public String showAddForm(Model model) {
		
		model.addAttribute("product", new Product());
		return "product-form";
	}
	
	@PostMapping("/products/save")
	public String saveProduct(@ModelAttribute Product product) {
		
		productService.addProduct(product);
		return "redirect:/products";
	}
	
	@GetMapping("/products/{id}")
	public String productDetails(@PathVariable int id, Model model)
	{
		model.addAttribute("product", productService.getProductById(id));
		return "product-details";
	}
	
	@GetMapping("/products/edit/{id}")
	public String showEditForm(@PathVariable int id, Model model)
	{
		model.addAttribute("product", productService.getProductById(id));
		return "product-form";
	}

}
