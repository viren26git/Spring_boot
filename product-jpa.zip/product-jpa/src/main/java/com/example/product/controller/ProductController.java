package com.example.product.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.model.Product;
import com.example.product.service.ProductService;

@RestController
@RequestMapping("/api/products") 
public class ProductController {
	
	private ProductService productService;   // DI injecting the service hee
	
	public ProductController(ProductService productService)
	{
		this.productService = productService;
	}
	
	@PostMapping("/add")
	public Product addProduct(@RequestBody Product product) {
		return productService.addProduct(product);
	}
	
	@GetMapping("/all")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Product> getSingleProduct(@PathVariable int id) {
		Optional<Product> product= productService.getSingleProduct(id);
		
		if(product.isPresent()) {
			return ResponseEntity.ok(product.get());
		}
		
		return ResponseEntity.notFound().build();
	}
	
	@PutMapping("/update/{id}") 
	public ResponseEntity<Product> updateProduct(@RequestBody Product product, @PathVariable int id) {
		Product updatedProduct =  productService.updateProduct(product, id);
		
		if(updatedProduct != null) {
			return ResponseEntity.ok(updatedProduct);
		}
		return ResponseEntity.notFound().build();
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteProduct(@PathVariable int id) { 
		boolean deleted = productService.deleteProduct(id);
		
		if(deleted) {
			return ResponseEntity.ok("Product deleted successfully");
		}
		return ResponseEntity.notFound().build();
	}
}
