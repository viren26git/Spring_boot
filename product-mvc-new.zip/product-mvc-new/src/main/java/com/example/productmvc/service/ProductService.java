package com.example.productmvc.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.example.productmvc.model.Product;

@Service
public class ProductService {
	
	private List<Product> products = new ArrayList<>();
	
	public ProductService() {
		products.add(new Product(1,"Laptop","Electronics",75000,10));
		products.add(new Product(2,"LED TV","Electronics",67000,40));
		products.add(new Product(3,"Headphones","Electronics",6700,100));
	}
	
	public List<Product> getAllProducts(){
		return products;
	}
	
	public Product getProductById(int id) {
		return products.stream().filter(p->p.getId() == id).findFirst().orElse(null);
	}
	
	public void addProduct(Product product) {
		products.add(product);
	}

}
