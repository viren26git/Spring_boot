package com.example.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import com.example.product.model.Product;
import com.example.product.repository.ProductRepository;

@Service
public class ProductService {
	
	//private List<Product> products = new ArrayList<>(); // empty list to store my products
	private ProductRepository pr;     // DI

	public ProductService(ProductRepository pr) {
		this.pr = pr;
	} 
	
	// create method
	public Product addProduct(Product product) {
		return pr.save(product);
	}
	
	//Read all products
	public List<Product> getAllProducts(){
		return pr.findAll();
	}
	
	// read single product
	public Optional<Product> getSingleProduct(int id) {
		return pr.findById(id);
	}
	
	// update product
	public Product updateProduct(Product updateProduct, int id) {
		
		Optional<Product> existingProduct = pr.findById(id);
		
		if(existingProduct.isPresent()) {
			Product p = existingProduct.get();
			
			p.setName(updateProduct.getName());
			p.setPrice(updateProduct.getPrice());
			p.setCategory(updateProduct.getCategory()); 
			
			return pr.save(p);
		}
		return null;
	}
	
	//delete Product
	public boolean deleteProduct(int id) {
		
		if(pr.existsById(id)) {
			pr.deleteById(id);
			return true;
		}
		return false;
	}
}
